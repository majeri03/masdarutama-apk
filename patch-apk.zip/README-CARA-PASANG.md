# README — CARA PASANG PAKET PERBAIKAN KE-5: APK (27 Nov 2026)

Paket perbaikan ke-5 (APK saja), atas permintaan Jery (27 Nov 2026, 20:09 WITA):
1. **Buat modal Kelola Supplier** di modal Buat PO (tombolnya ada tapi tidak
   membuka apa-apa).
2. **Audit APK menyeluruh** — cari bug lain yang belum sempat dicek user.

- Repo APK: `https://github.com/majeri03/masdarutama-apk`, HEAD GitHub **`08228ab`**.
- **Basis paket ini (WAJIB sudah terpasang di laptop Jery):** `08228ab` +
  5 patch APK paket ke-3 + `tsc-fix-duplikat-props.patch` + 2 patch APK
  paket ke-4. Jery sudah mengonfirmasi semua itu sudah dipasang di lokal
  (belum push).

> **BACA DULU — STATUS PAKET INI**
>
> Paket ini **BELUM terverifikasi / BELUM final**. Yang sudah dicek di sini:
> ke-4 patch lolos `git apply --check` + full apply **berurutan dalam satu
> fresh clone yang dirakit dari basis di atas** (total akhir 29 file,
> +803/−202 dari `08228ab`; kontribusi paket ke-5 saja +484/−81). Yang
> **TIDAK BISA** jalan di environment pembuat paket ini: `npx tsc` dan
> EAS build (tidak ada `node_modules` / toolchain di sana), serta hasil
> nyata di HP (tidak ada emulator). **Laptop Jery yang memutuskan:
> `npx tsc --noEmit` HARUS lolos sebelum commit + push, dan EAS build
> HARUS sukses sebelum install APK.** Kalau gagal, JANGAN push/install —
> kirim baris error paling bawah ke Jett.
>
> **Tidak ada migrasi database dan tidak ada patch web di paket ini.**

---

## 0. Sebelum mulai — cek posisi repo

```powershell
cd D:\laragon\www\proyekmasdarutama\masdarutamaapk
git status
git log --oneline -1
```

Pastikan: tidak ada perubahan yang belum di-commit, dan paket ke-3 +
tsc fix + paket ke-4 sudah terpasang di repo lokal (file
`src/utils/invoicePdf.ts` sudah punya `getInvoicePdfPageSize` dan
`app.json` sudah `"userInterfaceStyle": "light"` — itu tanda paket ke-4
sudah ada). Kalau belum, **berhenti** dan pasang paket ke-3 + ke-4 dulu.

**Download-first:** simpan file `.zip` lalu extract ke folder repo, baru
jalankan `git apply`. Jangan apply dari folder lain.

---

## 1. Pasang 4 patch (HARUS berurutan)

Download dulu `patch-apk.zip`, extract ke folder repo sehingga ada folder
`patch-apk\` berisi 4 file patch.

```powershell
cd D:\laragon\www\proyekmasdarutama\masdarutamaapk
git apply patch-apk\ws-1-modal-supplier.patch
git apply patch-apk\ws-2-audit-pos-penjualan.patch
git apply patch-apk\ws-3-audit-produk-stok.patch
git apply patch-apk\ws-4-audit-armada-pengaturan.patch
```

| No | File patch | Isi singkat |
|----|-----------|-------------|
| 1 | `ws-1-modal-supplier.patch` | Modal "Kelola Supplier" di Buat PO: pilih supplier dari daftar, tambah baru (langsung terpilih di PO), ubah, hapus |
| 2 | `ws-2-audit-pos-penjualan.patch` | 8 bug: crash Edit Transaksi, piutang UMUM lewat edit, qty 0/diskon berlebih, saklar Logo hilang, ukuran dokumen custom, toast palsu, key duplikat POS, modal zoom mati |
| 3 | `ws-3-audit-produk-stok.patch` | 6 bug: badge produk salah, huruf lolos di nominal bayar utang, daftar ganda saat total pas 30, foto bukti DO tidak terhapus, laporan tidak ikut periode, hasil cari basi |
| 4 | `ws-4-audit-armada-pengaturan.patch` | 5 bug: 3 tombol pintasan mati, "Buka Pengaturan" GPS mati, toggle printer tidak tersimpan, "Sinkronisasi Data" palsu, email login tidak di-trim |

Lalu type check + commit + push:

```powershell
npx tsc --noEmit
git add -A
git commit -m "perbaikan ke-5 apk 27 nov 2026"
git push
```

Kalau `tsc` gagal, kirim errornya ke Jett, jangan lanjut.

---

## 2. EAS BUILD BARU — WAJIB (perubahan APK tidak terlihat tanpa ini)

Setelah push:

```powershell
cd D:\laragon\www\proyekmasdarutama\masdarutamaapk
eas build --platform android --profile production
```

Download file `.apk` hasil build, install di HP (timpa APK lama). **Tanpa
build + install baru, semua perbaikan di atas TIDAK akan terlihat.**
Perhatian: `app.json` paket ke-4 sudah `"userInterfaceStyle": "light"` —
perbaikan warna input itu hanya berlaku setelah EAS build baru ini, bukan
OTA.

---

## 3. Apa yang diperbaiki (ringkas, per item)

### WS-1 — Modal Kelola Supplier (Buat PO)

Tombol "+ Kelola Supplier" sebelumnya hanya mengubah state tanpa ada
modal yang dirender, padahal handler simpan/hapus dan semua state form
sudah ditulis tapi tak pernah terpakai. Sekarang modal layar penuh
(mengikuti pola modal paket ke-3/ke-4: bisa di-scroll, kaca cukup pekat,
tombol tidak terpotong, teks input terlihat): daftar supplier dengan
tanda centang — ketuk salah satu = terpilih di dropdown PO dan modal
tertutup; form tambah baru (Nama + Telepon wajib, Kode opsional) — setelah
simpan, daftar di-refresh dan supplier baru **langsung terpilih** di PO;
ikon pensil untuk ubah, ikon tong sampah untuk hapus (dengan konfirmasi;
bila yang dihapus sedang terpilih, pilihan dikosongkan).

**Temuan penting:** validasi handler lama salah arah terhadap backend —
ia mewajibkan nama + kode, padahal skema server mewajibkan **nama +
telepon** dan **kode dibuat otomatis server (SUP-xxx)**. Tanpa telepon,
server menolak dengan error yang sulit dibaca. Validasi kini: nama +
telepon wajib (di-trim), kode opsional. Endpoint `POST /api/suppliers`
dan `PUT/DELETE /api/suppliers/[id]` sudah ada — tidak ada endpoint baru.
`POST` mensyaratkan role minimum ADMIN (perilaku lama). Logika pembuatan
PO tidak disentuh sama sekali.

### WS-2 — Audit POS / Penjualan (8 bug)

1. **EditTransactionScreen — crash potensial:** `api.get('/api/customers')`
   dipakai mentah tanpa normalisasi bentuk respons; bila backend mengirim
   bentuk objek `{customers: [...]}`, `customers.filter/find` melempar
   TypeError → layar crash. Diperbaiki dengan normalisasi yang sama seperti
   `masterService.getCustomers` + `route.params ?? {}`.
2. **EditTransactionScreen — piutang untuk UMUM bisa dibuat lewat edit:**
   tidak ada penjaga CREDIT-vs-UMUM seperti di POS. Ditambah penjaga yang
   sama di `handleSubmit`.
3. **EditTransactionScreen — qty 0/negatif bisa tersimpan; diskon bisa
   melebihi total baris:** validasi submit (tolak qty < 1) + clamp diskon
   `0..(qty×harga)` di `updateItemField`/`updateItemUnit`, subtotal
   di-`Math.max(0, …)`.
4. **InvoiceLayoutScreen — saklar "Tampilkan Logo" tidak ada:** `showLogo`
   dipakai store, preview A4, sync server, dan PDF, tapi tidak ada kontrol
   UI-nya. Ditambah Switch (pola saklar lain).
5. **InvoiceLayoutScreen — ukuran dokumen custom tidak dipulihkan:** W/H
   di-hardcode 210/297; sekarang di-parse dari `invoicePaperSize` tersimpan.
6. **InvoiceLayoutScreen — toast sukses palsu:** `handleSave` tidak cek
   `res.data.success`; sekarang `success:false` → toast error.
7. **POSScreen — key duplikat** tombol uang cepat/DP cepat (bila grandTotal
   = 50rb/100rb/200rb atau DP sama). Key kini memakai indeks.
8. **TransactionHistoryScreen — modal zoom bukti pembayaran mati:**
   `showZoomModal`/`zoomImageUrl` tidak pernah di-set; preview tetap jalan
   lewat `ProofImageUploader`. Modal + state + import `Image` dihapus,
   tanpa perubahan perilaku.

Dinyatakan tidak ada bug: Dashboard (semua 18 rute quick action
terverifikasi ada), Customers, Points, Salesmen, `cart.store`,
`invoice-layout.store`, dan sebagian besar POS/Riwayat.

### WS-3 — Audit Produk / Stok / Delivery / Utang / Laporan (6 bug)

1. **ProductsScreen — badge produk salah:** produk aktif tampil badge
   **"Diterima"**, nonaktif **"Dibatalkan"** (itu status penjualan, bukan
   produk). Diganti badge inline "Aktif"/"Nonaktif".
2. **DebtScreen — huruf di nominal bayar lolos validasi:** `Number('abc')`
   = `NaN`, dan `NaN <= 0` = `false`, lalu terkirim sebagai `amount: null`.
   Ditambah cek `isNaN(amountNum)`.
3. **DeliveryScreen + DebtScreen — daftar jadi ganda tanpa henti saat
   scroll kalau total data pas 30:** backend mengabaikan `page`/`limit`
   (dinyatakan di komentar kedua layar), halaman berikut mengembalikan 30
   baris yang sama dan langsung di-append (30→60→90…). Sekarang didedupe
   by id; kalau tidak ada item baru, `hasMore=false`.
4. **DeliveryScreen — foto bukti di kolom `proofImage` tidak pernah
   dihapus dari R2 saat DO dihapus** (blok hapus hanya jalan kalau `notes`
   terisi, dan hanya menghapus URL marker di notes), padahal Alert
   menjanjikan semua foto bukti dihapus. Sekarang URL `proofImage` ikut
   dihapus (didedupe), tetap non-blocking.
5. **ReportsScreen — daftar transaksi tidak mengikuti periode:** `getSales`
   dipanggil tanpa `dateFrom`/`dateTo` untuk Harian/Mingguan/Bulanan, jadi
   PDF "Periode: Hari Ini" bisa berisi transaksi hari lain. Sekarang range
   kalender lokal diteruskan (Harian = hari ini, Mingguan = Senin–Minggu,
   Bulanan = 1 s.d. akhir bulan; Tahunan tetap). Ringkasan angka sudah
   benar (pakai `period` backend) dan tidak diubah.
6. **StockOpnameScreen + DeliveryScreen — hasil cari produk basi saat
   query dihapus sampai ≤1 huruf** (pencarian hanya jalan kalau >1 huruf,
   daftar lama tidak dibersihkan). Sekarang daftar dikosongkan.

### WS-4 — Audit Armada / Pengaturan / Notifikasi / Profil / Login (5 bug)

1. **FloatingShortcut — 3 dari 4 tombol pintasan mati.** `navigateTo()`
   memanggil `navigate('POS'/'Products'/'History')` langsung dari root
   stack, padahal ketiganya tab di `MainTabNavigator` → tidak ditangani.
   Perbaikan: tab lewat `navigate('Main', { screen })`.
2. **FleetTracking — tombol "Buka Pengaturan" tidak membuka apa-apa.**
   `onPress` hanya memanggil `Location.getForegroundPermissionsAsync()`
   (membaca status izin). Diganti `Linking.openSettings()`.
3. **Settings — toggle printer tidak pernah tersimpan.** `usePrinter` /
   `printReceipt` hanya `useState` lokal, tidak dibaca file lain mana pun.
   Sekarang disimpan ke AsyncStorage dan dipulihkan saat layar dibuka.
4. **Settings — "Sinkronisasi Data" palsu.** `onPress` hanya menampilkan
   Alert "sedang disinkronisasi" tanpa memanggil API. Sekarang benar-benar
   `fetchSettings()` (`GET /api/settings`) + toast hasil; deskripsi
   disesuaikan ("Perbarui info toko dari server").
5. **Login — email tidak di-trim.** Spasi di akhir (mudah dari keyboard HP)
   membuat login gagal padahal password benar. Sekarang di-trim sebelum
   login dan sebelum disimpan ke SecureStore.

Verifikasi ulang poin khusus — semua masih benar: menu Tracking Armada
muncul untuk ADMIN/KASIR; GPS hanya sopir yang ditugaskan; hapus R2
berpesan jujur; avatar memakai `POST /api/profile/avatar`; cek update
membandingkan `versionCode` angka dan melempar error fetch (bukan "Sudah
Terbaru"); notifikasi dibaca/dihapus tidak muncul lagi.

---

## 4. Yang TIDAK diperbaiki (dengan alasan)

- **WS-2, perlu konfirmasi user:** apakah EditTransaction boleh menyimpan
  CASH dengan bayar < grandTotal / DP CREDIT > grandTotal (POS melarang
  keduanya, edit tidak memvalidasi) — belum ditambahkan, perlu keputusan.
- **WS-3:** chip status + tanggal Delivery tidak langsung diterapkan —
  baru jalan setelah ketuk "Terapkan Filter"; tampak disengaja, perlu
  konfirmasi. Ringkasan total Utang dihitung dari baris yang termuat
  (benar saat ini; berisiko kurang kalau backend suatu hari mem-page
  server-side — perbaikan benar ada di backend). `renderDOItem` kode mati
  dan `getDeliveryPhotos` tidak pernah dipakai — dibiarkan (bukan bug).
  Filter tanggal Utang client-side (bekerja, tidak diubah). Arti `quantity`
  ADJUSTMENT di server dan definisi minggu backend tidak bisa dipastikan
  dari kode APK — asumsi minggu Senin–Minggu di ReportsScreen perlu
  konfirmasi backend.
- **WS-4 (T1–T8, di NOTES):** T1 toggle printer tersimpan tapi alur cetak
  POS belum membacanya (perlu pemilik POS); T2 seksi "Informasi Toko"
  tampil untuk KASIR padahal komentar bilang hanya Admin/SuperAdmin (soal
  role, tidak diubah); T3 `ProofImageUploader` menghapus referensi foto
  walau hapus R2 gagal; T4 `handleConnect` memakai state `scanning` (teks
  menyesatkan); T5 fallback `App-Prefs:Bluetooth` iOS; T6 avatar tidak
  tampil di drawer; T7 login selalu menyimpan kredensial tanpa pilihan
  (disengaja per komentar); T8 import `useEffect` tak terpakai di
  LoginScreen.
- Semua temuan yang mencurigakan tapi belum tentu bug dicatat di NOTES
  masing-masing workstream, tidak diperbaiki diam-diam.

---

## 5. Setelah install — yang harus dites

- **Kelola Supplier:** buka Buat PO → "+ Kelola Supplier" → modal terbuka;
  pilih supplier dari daftar → terpilih di PO dan modal tertutup; tambah
  baru tanpa kode (nama + telepon) → tersimpan dan langsung terpilih;
  ubah nama/telepon; hapus supplier → hilang dari daftar.
- **Edit Transaksi:** buka edit transaksi → coba simpan CREDIT untuk
  customer UMUM → harus ditolak; qty 0 → ditolak; diskon melebihi total
  baris → dipotong.
- **Invoice Layout:** saklar "Tampilkan Logo" ada dan berfungsi; ukuran
  dokumen custom (mis. bukan A4) dipulihkan setelah buka ulang; simpan
  yang gagal → toast error, bukan sukses.
- **POS:** tombol uang cepat/DP cepat saat total 50rb/100rb/200rb → tidak
  error; riwayat → ketuk bukti pembayaran → preview jalan.
- **Produk:** badge produk aktif "Aktif", nonaktif "Nonaktif".
- **Utang:** ketik huruf di nominal bayar → ditolak; scroll daftar utang
  yang totalnya pas 30 → tidak ada duplikat.
- **Delivery:** hapus DO yang punya foto bukti → foto ikut terhapus dari
  R2; scroll daftar DO yang totalnya pas 30 → tidak ada duplikat; cari
  produk lalu hapus ketikan → daftar bersih.
- **Laporan:** pilih periode Harian/Mingguan/Bulanan → daftar transaksi
  dan PDF mengikuti periode itu.
- **Pintasan:** 4 tombol pintasan mengambang → semuanya membuka layar
  yang benar. **Armada:** tombol "Buka Pengaturan" saat izin lokasi mati
  → membuka Pengaturan Aplikasi. **Pengaturan:** toggle printer → tutup
  lalu buka lagi → tetap tersimpan; "Sinkronisasi Data" → benar-benar
  memperbarui info toko. **Login:** email dengan spasi di akhir → tetap
  bisa login.

---

## 6. Isi paket

```
perbaikan-ke-5-20261127/
├── README-CARA-PASANG.md            ← file ini (juga di dalam zip)
├── patch-apk.zip                    ← 4 patch APK (siap extract ke repo APK)
├── patch-apk/                       ← isi zip APK (folder datar)
├── ws-1-modal-supplier/             (patch APK + NOTES)
├── ws-2-audit-pos-penjualan/        (patch APK + NOTES)
├── ws-3-audit-produk-stok/          (patch APK + NOTES)
└── ws-4-audit-armada-pengaturan/    (patch APK + NOTES)
```

Tiap folder berisi file `.patch` + `NOTES.md` (diagnosis, apa yang diubah,
kenapa, apa yang TIDAK diubah, dan daftar cek). Baca NOTES folder yang
bersangkutan kalau ada yang kurang jelas sebelum memasang.

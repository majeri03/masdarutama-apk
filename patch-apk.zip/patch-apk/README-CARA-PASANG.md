# README — CARA PASANG PAKET PERBAIKAN APK + WEB (25 Nov 2026)

Paket perbaikan 9 masalah dari tes APK Jery (25 Nov 2026, 19:55 WITA):
armada/GPS, notifikasi ganda, printer blank, tombol cepat, logo OTP login,
invoice APK = web, manifest + cek pembaruan, UI salesman + poin, warna/background APK.

- Repo web: `https://github.com/majeri03/tbmasdarutama`, HEAD **`e005dfc9`**
  ("perbaikan gabungan 44 item hasil blackbox 24-25 Nov 2026").
- Repo APK: `https://github.com/majeri03/masdarutama-apk`, HEAD **`016212c`**.

> **BACA DULU — STATUS PAKET INI**
>
> Paket ini **BELUM terverifikasi / BELUM final**. Yang sudah dicek di sini:
> ke-10 patch APK lolos `git apply --check` + full apply **berurutan dalam
> satu fresh clone `016212c`** (32 file, +2392/−712), dan ke-3 patch web
> lolos `git apply --check` + full apply **berurutan dalam satu fresh clone
> `e005dfc9`** (10 file, +603/−113). Sweep file `"use server"` di pohon web
> hasil rakitan bersih (tidak ada export fungsi non-async). Yang **TIDAK
> BISA** jalan di environment pembuat paket ini: `npx tsc`, `npm run build`,
> dan EAS build (tidak ada `node_modules` / toolchain di sana).
> **Laptop Jery yang memutuskan: `npx tsc --noEmit` dan `npm run build`
> (web) HARUS lolos sebelum commit + push, dan EAS build HARUS sukses
> sebelum install APK.** Kalau gagal, JANGAN push/install — kirim baris
> error paling bawah ke Jett.
>
> **URUTAN DEPLOY WAJIB: web dulu, baru APK.** Patch web harus sudah
> di-deploy ke Vercel SEBELUM EAS build APK dijalankan — APK membaca field
> baru dari backend (total salesman/poin) dan parameter notifikasi baru;
> kalau APK dipasang duluan, kolom total di APK tampil Rp0 sementara dan
> navigasi notifikasi belum lengkap.

---

## 0. Sebelum mulai — cek posisi repo

```powershell
cd D:\laragon\www\proyekmasdarutama\tbmasdarutama
git status
git log --oneline -1
cd D:\laragon\www\proyekmasdarutama\masdarutamaapk
git status
git log --oneline -1
```

Pastikan: tidak ada perubahan yang belum di-commit, HEAD web `e005dfc9`,
HEAD APK `016212c`. Kalau HEAD sudah bukan itu (ada push baru),
**berhenti** dan tanya Jett dulu.

**Download-first:** simpan file `.patch` ke dalam folder repo dulu, baru
jalankan `git apply`. Jangan apply dari folder lain.

---

## 1. BAGIAN A — Patch web (3 patch, HARUS berurutan)

Pasang di repo backend (`D:\laragon\www\proyekmasdarutama\tbmasdarutama`).
Download dulu file zip `patch-web.zip`, extract ke folder repo sehingga ada
folder `patch-web\` berisi 3 file patch.

```powershell
cd D:\laragon\www\proyekmasdarutama\tbmasdarutama
git apply patch-web\ws-1-fleet-web.patch
git apply patch-web\ws-2-notifikasi-web.patch
git apply patch-web\ws-8-salesman-poin-web.patch
```

| No | File patch | Isi singkat |
|----|-----------|-------------|
| 1 | `ws-1-fleet-web.patch` | Tambah/edit/hapus kendaraan = SUPER_ADMIN saja (API + halaman web); ADMIN tetap bisa lihat semua |
| 2 | `ws-2-notifikasi-web.patch` | Notifikasi stok rendah kini mengirim `productId`/`productName`; GET `/api/notifications` tidak lagi mengembalikan JSON mentah sebagai pesan |
| 3 | `ws-8-salesman-poin-web.patch` | Tabel Salesman + Poin baru (filter, urutan, total); `getSalesmen`/`getCustomers` mengembalikan total per baris (rumus fee/poin TIDAK berubah) |

Tidak ada migrasi database di paket ini — `npx prisma migrate deploy` TIDAK
diperlukan. Lanjut type check + build:

```powershell
npx tsc --noEmit
npm run build
```

- Kalau `tsc` gagal: kirim errornya ke Jett, jangan lanjut.
- Kalau `npm run build` gagal: yang penting **satu error di baris paling
  bawah** log — kirim baris itu. Pelajaran lama: `tsc` lolos TIDAK menjamin
  build lolos.
- Kalau keduanya lolos, baru commit + push:

```powershell
git add -A
git commit -m "perbaikan apk+web 9 item hasil tes apk 25 nov 2026"
git push
```

Vercel akan deploy otomatis. **Tunggu deploy selesai (status Success) sebelum
lanjut ke Bagian B.**

---

## 2. BAGIAN B — Patch APK (10 patch, HARUS berurutan)

Pasang di repo APK (`D:\laragon\www\proyekmasdarutama\masdarutamaapk`).
Download dulu file zip `patch-apk.zip`, extract ke folder repo sehingga ada
folder `patch-apk\` berisi 10 file patch + `update-manifest.json`.

```powershell
cd D:\laragon\www\proyekmasdarutama\masdarutamaapk
git apply patch-apk\ws-2-notifikasi-apk.patch
git apply patch-apk\ws-3-printer.patch
git apply patch-apk\ws-5-otp-logo.patch
git apply patch-apk\ws-4-quick-actions.patch
git apply patch-apk\ws-6-invoice-apk.patch
git apply patch-apk\ws7-manifest-update-checker.patch
git apply patch-apk\ws-8-salesman-poin-apk.patch
git apply patch-apk\ws-1-fleet-apk.patch
git apply patch-apk\ws-9-ui-colors.patch
git apply patch-apk\koordinator.patch
```

| No | File patch | Isi singkat |
|----|-----------|-------------|
| 1 | `ws-2-notifikasi-apk.patch` | JSON mentah tidak pernah dirender lagi; dedup notifikasi; tombol hapus per item; hapus/baca bertahan; navigasi stok rendah → detail produk; pesanan baru → detail penjualan |
| 2 | `ws-3-printer.patch` | Layar printer tidak blank lagi (init BLE tidak blocking, gerbang izin di service, banner error + tombol Coba Lagi) |
| 3 | `ws-5-otp-logo.patch` | Logo login + ikon OTP pindah ke dalam card, ukuran responsif, layar bisa di-scroll |
| 4 | `ws-4-quick-actions.patch` | Tombol cepat bisa ditambah banyak + susun ulang (mode edit, 18 fitur, simpan per user) |
| 5 | `ws-6-invoice-apk.patch` | Invoice APK = web, dinamis dari API (info toko, rekening, layout, watermark); tombol Simpan benar-benar menyimpan; bug Surat Jalan merusak layout diperbaiki; escape HTML |
| 6 | `ws7-manifest-update-checker.patch` | Cek pembaruan diperbaiki (validasi hash setelah banding versi, error fetch tidak lagi jadi "Sudah Terbaru", mandatory benar-benar memaksa, `autoIncrement` dihapus dari eas.json) |
| 7 | `ws-8-salesman-poin-apk.patch` | Tabel Salesman + Poin baru (filter, urutan, total) — butuh patch web Bagian A sudah deploy |
| 8 | `ws-1-fleet-apk.patch` | Tambah/edit/hapus = SUPER_ADMIN; GPS hanya sopir yang ditugaskan; popup panduan pertama kali; menu Tracking Armada muncul untuk ADMIN/KASIR; empty state dibedakan |
| 9 | `ws-9-ui-colors.patch` | Palet ungu/biru → merah merek `#7F1D1D`, background biru-abu → abu netral, kartu tidak menumpuk 2 lapis |
| 10 | `koordinator.patch` | Sisa ungu/biru di Settings + gradien drawer (temuan WS-9 di file yang dihindari) |

Lalu type check + commit + push:

```powershell
npx tsc --noEmit
git add -A
git commit -m "perbaikan apk 9 item hasil tes apk 25 nov 2026"
git push
```

Kalau `tsc` gagal, kirim errornya ke Jett, jangan lanjut.

---

## 3. EAS BUILD BARU — WAJIB (perubahan APK tidak terlihat tanpa ini)

Setelah Bagian B di-push:

```powershell
cd D:\laragon\www\proyekmasdarutama\masdarutamaapk
eas build --platform android --profile production
```

Download file `.apk` hasil build, install di HP (timpa APK lama). **Tanpa
build + install baru, semua perbaikan APK di atas TIDAK akan terlihat.**

---

## 4. MANIFEST + FILE APK DI GOOGLE DRIVE — WAJIB, URUTAN PENTING

Manifest TIDAK ada di repo — manifest adalah file JSON di **Google Drive**
(file ID `15dZHNf5cy6ZOeicCZEFsQgm1UaLZTcrq`). Temuan penting: file APK di
Drive saat ini **masih v1.0.0 / versionCode 2, bukan 1.1.1/3** (dibuktikan
dengan parse AndroidManifest.xml). Kalau tidak diganti, user yang update
akan dapat APK 1.0.0 lagi — loop update tanpa ujung.

Langkah rilis 1.1.1 (file `update-manifest.json` di folder `patch-apk\`
adalah manifest baru yang sudah diperbaiki — release notes Bahasa Indonesia,
versi tetap 1.1.1/code 3 cocok dengan `app.json`):

1. Jalankan EAS build production (§3) sampai selesai.
2. Upload file `.apk` hasil build sebagai **versi baru dari file Drive yang
   sama** (buka file APK lama di Drive → Kelola versi → Upload versi baru).
   ID file tetap sama, jadi `apkUrl` tidak berubah.
3. Hitung SHA-256 dari file APK yang baru (mis. PowerShell:
   `Get-FileHash -Algorithm SHA256 <file.apk>`).
4. Buka file manifest di Drive, ganti isi `sha256` dari
   `"GANTI_DENGAN_SHA256_APK_1.1.1_YANG_BARU_DIBUILD"` dengan hash asli dari
   langkah 3, lalu simpan. **JANGAN pakai hash lama `96408267…` — itu hash
   APK 1.0.0.**
5. Cek dashboard EAS: versionCode berapa yang tercatat untuk build
   production terakhir. `autoIncrement` sudah dihapus dari `eas.json`, jadi
   sumber versi tunggal sekarang `app.json` + `scripts/bump-version.js`.
   Kalau versionCode di EAS sudah terlanjur 4 karena `autoIncrement` lama,
   build berikutnya perlu `bump:patch` dulu (lihat NOTES WS-7 §6).

Catatan: host tetap Google Drive (rapuh — halaman peringatan virus-scan).
Kalau nanti mau pindah ke hosting dengan direct link stabil (mis. file
statis di Vercel), itu keputusan terpisah — lihat NOTES WS-7.

---

## 5. Yang diputuskan / diubah perilakunya (sudah diterapkan di patch)

- **Item 1 (armada):** tambah/edit/hapus kendaraan = SUPER_ADMIN saja (web +
  APK + API). ADMIN boleh LIHAT semua armada, tidak boleh tambah/edit/hapus.
  GPS "Mulai" hanya sopir utama/pendamping yang ditugaskan, dari HP-nya
  sendiri — ADMIN/SUPER_ADMIN tidak bisa lagi memulai GPS (API location
  tetap menerima ADMIN+; hanya UI yang dikunci — kalau nanti mau API juga
  menolak ADMIN, itu perubahan terpisah). Menu Tracking Armada kini muncul
  untuk ADMIN/KASIR lewat `minRole: 'KASIR'` di drawer (dipilih mengikuti
  preseden Salesman/Poin, BUKAN mendaftarkan kunci ke `PAGE_KEYS` — kunci
  baru akan ter-seed nonaktif dan menu tetap tidak muncul). KASIR tanpa
  penugasan melihat "Belum Ada Penugasan", bukan "Belum Ada Armada".
  `GET /api/fleet/vehicles` TIDAK dilonggarkan (filter penugasan = pentest
  fix M21).
- **Item 2 (notifikasi):** JSON mentah tidak pernah dirender lagi (diubah
  jadi "Pesanan baru — Invoice #INV-…"). Hapus/baca kini bertahan (tombol
  hapus per item, hapus menunggu tandai-baca dulu, logout menandai semua
  dibaca dulu baru menghapus). Stok rendah → detail produk spesifik (bukan
  daftar produk). Baris JSON lama di DB produksi TIDAK dihapus via SQL —
  kini tampil bersih dan bisa dihapus per item dari APK.
- **Item 6 (invoice):** web adalah sumber kebenaran — server menimpa layout
  lokal APK tiap cetak/buka layar (termasuk mengosongkan rekening bila
  dihapus di web). Reset layout kini mengembalikan rekening kosong (bukan
  `BRI 4055505757`); isi rekening di Pengaturan web bila mau ada isinya.
- **Item 7 (manifest):** versi TIDAK dinaikkan (tetap 1.1.1/3, cocok
  `app.json`). `mandatory` tetap `false`.
- **Item 8 (salesman/poin):** hanya tampilan yang diubah — rumus fee/poin,
  endpoint, dan role TIDAK berubah. "Total Belanja (Lunas)" dihitung dari
  penjualan COMPLETED bukan CREDIT (sejalan dengan syarat dapat poin).
- **Item 9 (warna):** biru semantik dipertahankan (info, transfer, status
  Servis) — hanya aksen biru-ungu yang diganti merah merek. Semua tombol
  utama kini merah gelap `#7F1D1D` — lihat dulu di HP hasil build; bila
  terasa terlalu gelap, alternatif `#991B1B` sebagai `primary`.

---

## 6. Yang TIDAK diperbaiki (dengan alasan)

- **Item 2:** baris JSON lama di DB tidak dihapus via SQL (tampil bersih +
  bisa dihapus per item). Kolom `dedupKey` tidak ditambahkan (didedup dari
  params, tanpa migrasi). Helper mati `notify.ts`/`notifications.ts` dan
  rute FCM lama tidak dihapus (di luar item). Notifikasi stok rendah
  agregat (banyak produk) tetap membuka daftar produk — kalau mau daftar
  itu terfilter hanya produk rendah, itu item terpisah.
- **Item 3:** kode native library printer tidak di-patch (tinggal di
  `node_modules`, bukan repo) — perlindungan dilakukan dari JS.
  `BluetoothSocket.connect()` yang blocking tidak bisa diubah dari JS;
  hanya dihindari.
- **Item 4:** "Kas" dan "Supplier" tidak ada di pemilih (tidak ada layarnya
  di APK). Tanpa drag-and-drop (butuh dependensi baru) dan tanpa sinkron
  server (pilihan hanya lokal di HP).
- **Item 5:** logo di DALAM email OTP (template email server) bukan APK —
  kalau itu yang dimaksud user, ranahnya backend/web.
- **Item 7:** host tetap Google Drive; endpoint backend
  `/api/mobile/update-check` tidak diaktifkan; tidak ada auto-check saat
  startup; update wajib tidak bisa memaksa 100% (user bisa menutup
  aplikasi).
- **Item 8:** tanpa paginasi (daftar masih full list; `getCustomers`
  dibatasi 200) dan tanpa ekspor CSV/PDF.

---

## 7. Follow-up yang butuh keputusan Jery

1. **Item 1:** apakah API location juga harus menolak ADMIN memulai GPS
   (saat ini hanya UI yang dikunci)?
2. **Item 2:** baris JSON lama di DB produksi — bersihkan sekali via SQL
   setelah patch terpasang, atau biarkan (rekomendasi WS-2: biarkan, hapus
   via tombol APK saat terlihat)?
3. **Item 4:** apakah "Update Aplikasi" & "Kelola Penyimpanan" boleh tetap
   di pemilih tombol cepat? Apakah FloatingShortcut juga harus mengikuti
   pilihan tombol cepat? Apakah pilihan tombol cepat perlu ikut saat ganti
   HP (butuh endpoint backend baru)?
4. **Item 5:** logo login sebelumnya sengaja di ATAS card (PKG-D) — patch
   ini memindahkannya KE DALAM card sesuai laporan. Kalau Jery mau logo
   tetap di atas card dan hanya anti-terpotong, pemindahan bisa dibatalkan
   sebagian (tinggal ScrollView + logo responsif). Konfirmasi saat tes APK.
   Juga: bila yang dimaksud adalah logo di email OTP, beri tahu Jett.
5. **Item 6:** arah sinkronisasi web → APK sudah diputuskan (lihat §5).
6. **Item 7:** tetap Google Drive, atau pindah hosting APK+manifest (mis.
   Vercel) demi direct link yang stabil? Apakah rilis 1.1.1 ini wajib
   (`mandatory: true`) atau tetap opsional (`false`)? Cek versionCode di
   dashboard EAS (lihat §4 langkah 5).
7. **Item 8:** definisi "Total Belanja (Lunas)" — mau mencakup CREDIT juga?
   Total fee salesman — mau mengeluarkan CANCELLED/RETURN (saat ini
   mengikuti `getSalesmanDetail` yang sudah ada)?
8. **Item 9:** biru info dipertahankan atau dihapus total? Ikon Cloudflare
   R2 di Settings sudah disamakan ke merah merek (patch koordinator).
   Bila tombol utama terasa terlalu gelap, alternatif `#991B1B`.

---

## 8. Setelah deploy + install — yang harus dites ulang

- Armada: login SUPER_ADMIN (tambah/edit/hapus bisa), ADMIN (lihat semua,
  tombol tambah hilang), KASIR ditugaskan (popup panduan pertama kali +
  GPS bisa dimulai), KASIR tidak ditugaskan (empty state "Belum Ada
  Penugasan" + menu Tracking Armada tampil di drawer).
- Notifikasi: buat 1 pesanan baru → hanya 1 notifikasi bersih (tanpa JSON);
  ketuk notifikasi stok rendah → detail produk yang benar; ketuk pesanan
  baru → detail penjualan yang benar; hapus notifikasi → tutup/buka APK →
  tidak muncul lagi; baca semua → badge hilang.
- Printer: buka Pengaturan → Perangkat Printer dengan Bluetooth mati,
  izin ditolak, dan printer tersimpan mati — layar tidak boleh blank
  (banner error + tombol Coba Lagi bila gagal); cetak dari POS tanpa buka
  Pengaturan.
- Tombol cepat: tambah/hapus/pindah tombol, tutup-buka aplikasi (pilihan
  tersimpan), ganti akun, akun KASIR (fitur yang tidak diizinkan tidak
  muncul di pemilih), ketuk tiap tombol (navigasi benar).
- Login/OTP: logo di dalam card di HP kecil dan besar, keyboard terbuka,
  kotak kuning OTP muncul.
- Invoice: ubah info toko/rekening di web → cetak dari APK (harus ikut
  berubah); Simpan di Desain Invoice APK → cek di web (harus tersimpan);
  buat Surat Jalan → invoice berikutnya TIDAK ikut jadi Surat Jalan.
- Update: layar Pembaruan → "Cek Pembaruan" di 1.1.1 (tidak boleh error
  "Gagal Memperbarui" bila tidak ada update); matikan internet → tampil
  "Gagal Memperbarui", bukan "Sudah Terbaru".
- Salesman/Poin: filter + urutan + total di web dan APK; bandingkan angka
  total tabel dengan modal detail (harus sama).
- Warna: buka semua layar — tidak ada lagi ungu/background menumpuk;
  tombol utama merah gelap.

---

## 9. Isi paket

```
perbaikan-apk-20261125/
├── README-CARA-PASANG.md            ← file ini
├── patch-apk.zip                    ← 10 patch APK + update-manifest.json (siap extract ke repo APK)
├── patch-web.zip                    ← 3 patch web (siap extract ke repo backend)
├── patch-apk/                       ← isi zip APK (folder datar)
├── patch-web/                       ← isi zip web (folder datar)
├── ws-1-fleet-gps/                  (patch APK + web + NOTES)
├── ws-2-notifikasi/                 (patch APK + web + NOTES)
├── ws-3-printer/                    (patch APK + NOTES)
├── ws-4-quick-actions/              (patch APK + NOTES)
├── ws-5-otp-logo/                   (patch APK + NOTES)
├── ws-6-invoice/                    (patch APK + NOTES)
├── ws-7-manifest/                   (patch APK + update-manifest.json + NOTES)
├── ws-8-salesman-poin/              (patch APK + web + NOTES)
├── ws-9-ui-colors/                  (patch APK + NOTES)
└── 10-koordinator/                  (patch koordinator + NOTES)
```

Tiap folder berisi file `.patch` + `NOTES.md` (apa yang diubah, kenapa, apa
yang TIDAK diubah, dan apa yang belum terverifikasi di sini). Baca NOTES
folder yang bersangkutan kalau ada yang kurang jelas sebelum memasang.
